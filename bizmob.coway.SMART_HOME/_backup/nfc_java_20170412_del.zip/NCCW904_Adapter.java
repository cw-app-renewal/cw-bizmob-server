package adapter.nfc;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.codehaus.jackson.JsonNode;
import org.springframework.beans.factory.annotation.Autowired;

import adapter.common.NfcCommonResponse;
import adapter.model.NCCW904.NCCW904Request;
import adapter.model.NCCW904.NCCW904Request_Body;
import adapter.model.NCCW904.NCCW904Request_Body_I_ITAB;
import adapter.model.NCCW904.NCCW904Response;
import adapter.model.NCCW904.NCCW904Response_Body;
import adapter.model.header.CowayCommonHeader;

import com.mcnc.bizmob.adapter.AbstractTemplateAdapter;
import com.mcnc.bizmob.adapter.DBAdapter;
import com.mcnc.bizmob.adapter.exception.AdapterException;
import com.mcnc.smart.common.logging.ILogger;
import com.mcnc.smart.common.logging.LoggerService;
import com.mcnc.smart.db.type.DBMap;
import com.mcnc.smart.hybrid.adapter.api.Adapter;
import com.mcnc.smart.hybrid.adapter.api.IAdapterJob;
import com.mcnc.smart.hybrid.common.code.Codes;
import com.mcnc.smart.hybrid.common.server.JsonAdaptorObject;

@Adapter(trcode = { "NCCW904" })
public class NCCW904_Adapter extends AbstractTemplateAdapter implements
		IAdapterJob {

	private static final ILogger logger = LoggerService
			.getLogger(NCCW904_Adapter.class);
	@Autowired
	private DBAdapter dbAdapter;

	public JsonAdaptorObject onProcess(JsonAdaptorObject obj) {

		JsonNode reqRootNode = obj.get(JsonAdaptorObject.TYPE.REQUEST);
		JsonNode reqHeaderNode = reqRootNode.findValue(Codes._JSON_MESSAGE_HEADER);		
		
		NCCW904Request request				= new NCCW904Request ( obj );
//		CowayCommonHeader reqHeader			= request.getHeader();
		NCCW904Request_Body reqBody			= request.getBody();
		List< NCCW904Request_Body_I_ITAB > reqList	= reqBody.getI_ITAB();
		
		logger.info( ">>>> NCCW904 REQUEST ::" );
		logger.info( obj.toString() );
		
		NCCW904Response_Body resBody	= new NCCW904Response_Body(); 		
		JsonAdaptorObject resObj 		= new JsonAdaptorObject();
		
		SqlSession session	= dbAdapter.openSession( "BIZMOBNFC", false );
		try {
			DBMap queryParameters = new DBMap();
			for ( NCCW904Request_Body_I_ITAB item : reqList ) {
				queryParameters.put( "I_GOODS_SN", item.getI_GOODS_SN() );
				queryParameters.put("I_ORDER_NO", item.getI_ORDER_NO() );
				queryParameters.put("I_EQUNR", item.getI_EQUNR() );
				queryParameters.put("I_ERROR_DATE", item.getI_ERROR_DATE() );
				queryParameters.put("I_E_CODE", item.getI_E_CODE() );
				queryParameters.put("I_USER_ID", item.getI_USER_ID() );
				
				int result	= dbAdapter.selectOne( "BIZMOBNFC", "NCCW904.selectErrorData", queryParameters, Integer.class );
				if ( result < 1 ) {//없는경우
					dbAdapter.insert( session, "NCCW904.insertErrorData", queryParameters );
				} else {
					dbAdapter.update( session, "NCCW904.updateErrorData", queryParameters );
				}
				queryParameters.clear();
			}
			
			dbAdapter.commitAndClose( session );
			
			NfcCommonResponse response = new NfcCommonResponse( reqHeaderNode );
			
			logger.info( ">>>> NCCW904 RESPONSE ::" );
			logger.info( response.getNfcCommonResponse().toString() );
			
			return makeResponse( resObj, response.getNfcCommonResponse() );
			
		} catch ( Exception e ) {
			dbAdapter.rollbackAndClose( session );
			logger.error( ">>>> NCCW904 Exception ::", e );
			
			//오류내용 저장중 에러가 발생하였습니다.
			NfcCommonResponse errResponse = new NfcCommonResponse();			
			
			try {
				errResponse.setNfcErrorMessage( "오류내용 저장중 오류가 발생하였습니다." );
				errResponse.setNfcCommonHeader( reqHeaderNode );
			} catch (AdapterException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			return makeResponse( resObj, errResponse.getNfcCommonResponse() );
		}		
	}

}
