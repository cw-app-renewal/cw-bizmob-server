package adapter.nfc;

import java.util.ArrayList;
import java.util.List;

import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.node.ArrayNode;
import org.codehaus.jackson.node.JsonNodeFactory;
import org.codehaus.jackson.node.ObjectNode;
import org.springframework.beans.factory.annotation.Autowired;

import adapter.common.NfcCommonResponse;
import adapter.model.NCCR901.NCCR901Request;
import adapter.model.NCCR901.NCCR901Request_Body;
import adapter.model.NCCR901.NCCR901Response_Body_O_ITAB;
import adapter.model.header.CowayCommonHeader;

import com.mcnc.bizmob.adapter.AbstractTemplateAdapter;
import com.mcnc.bizmob.adapter.DBAdapter;
import com.mcnc.bizmob.adapter.exception.AdapterException;
import com.mcnc.bizmob.adapter.util.AdapterUtil;
import com.mcnc.smart.common.logging.ILogger;
import com.mcnc.smart.common.logging.LoggerService;
import com.mcnc.smart.db.type.DBMap;
import com.mcnc.smart.hybrid.adapter.api.Adapter;
import com.mcnc.smart.hybrid.adapter.api.IAdapterJob;
import com.mcnc.smart.hybrid.common.code.Codes;
import com.mcnc.smart.hybrid.common.server.JsonAdaptorObject;

@Adapter(trcode = { "NCCR901" })
public class NCCR901_Adapter extends AbstractTemplateAdapter implements
		IAdapterJob {

	private static final ILogger logger = LoggerService
			.getLogger(NCCR901_Adapter.class);
	@Autowired
	private DBAdapter dbAdapter;

	public JsonAdaptorObject onProcess(JsonAdaptorObject obj) {
		
		JsonNode reqRootNode = obj.get(JsonAdaptorObject.TYPE.REQUEST);
		JsonNode reqHeaderNode = reqRootNode.findValue(Codes._JSON_MESSAGE_HEADER);
		
		NCCR901Request request		= new NCCR901Request( obj );
//		CowayCommonHeader reqHeader	= request.getHeader();
		NCCR901Request_Body reqBody	= request.getBody();		
		logger.info( ">>>> NCCR901 REQUEST ::" );
		logger.info( obj.toString() );
		
		List< NCCR901Response_Body_O_ITAB > list			= new ArrayList< NCCR901Response_Body_O_ITAB >();
		
		JsonAdaptorObject resObj 							= new JsonAdaptorObject();
		
		String goodsNo	= reqBody.getI_GOODS_SN();
		
		ArrayNode	monthList = JsonNodeFactory.instance.arrayNode();
		
		try {
			DBMap queryParameter	= new DBMap(); 
			queryParameter.put( "I_GOODS_SN", goodsNo );
					
			list	= (List<NCCR901Response_Body_O_ITAB>)dbAdapter.selectList( "BIZMOBNFC", "NCCR901.selectMonthDrinkList", queryParameter );
			logger.info( ">>>> NCCR901 SELECT RESULT ::" + AdapterUtil.ConvertJsonNode( list ) );
			if ( list.size() > 0 ) {
				for ( NCCR901Response_Body_O_ITAB item : list ) {
					ObjectNode	monthData = JsonNodeFactory.instance.objectNode();
					monthData.put( "O_MONTH", item.getO_MONTH() );
					monthData.put( "O_SUM_COLD_INT", item.getO_SUM_COLD_INT() );
					monthData.put( "O_SUM_HOT_INT", item.getO_SUM_HOT_INT() );
					monthData.put( "O_SUM_NORMAL_INT", item.getO_SUM_NORMAL_INT() );
					
					monthList.add( monthData );
				}
			}
			
			NfcCommonResponse response = new NfcCommonResponse( reqHeaderNode, monthList );
			
			logger.info( ">>>> NCCR901 RESPONSE ::" );
			logger.info( response.getNfcCommonResponse().toString() );
			
			return makeResponse( resObj, response.getNfcCommonResponse() );
		} catch ( Exception e ) {
			logger.error( ">>>> NCCR901 Exception :: ", e);
			
			NfcCommonResponse errResponse = new NfcCommonResponse();
			
			try {
				errResponse.setNfcErrorMessage( "음용량 조회중 오류가 발생하였습니다." );
				errResponse.setNfcCommonHeader( reqHeaderNode );
			} catch (AdapterException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			return makeResponse( resObj, errResponse.getNfcCommonResponse() );
		}
		
	}

}
