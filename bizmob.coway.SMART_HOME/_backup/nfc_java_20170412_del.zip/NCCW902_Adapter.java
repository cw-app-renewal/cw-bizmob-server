package adapter.nfc;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.codehaus.jackson.JsonNode;
import org.springframework.beans.factory.annotation.Autowired;

import adapter.common.NfcCommonResponse;
import adapter.model.NCCW901.NCCW901Request;
import adapter.model.NCCW901.NCCW901Request_Body;
import adapter.model.NCCW901.NCCW901Request_Body_I_ITAB;
import adapter.model.NCCW901.NCCW901Response;
import adapter.model.NCCW901.NCCW901Response_Body;
import adapter.model.NCCW902.NCCW902Request;
import adapter.model.NCCW902.NCCW902Request_Body;
import adapter.model.NCCW902.NCCW902Response;
import adapter.model.NCCW902.NCCW902Response_Body;
import adapter.model.header.CowayCommonHeader;

import com.mcnc.bizmob.adapter.AbstractTemplateAdapter;
import com.mcnc.bizmob.adapter.DBAdapter;
import com.mcnc.bizmob.adapter.exception.AdapterException;
import com.mcnc.smart.common.logging.ILogger;
import com.mcnc.smart.common.logging.LoggerService;
import com.mcnc.smart.db.type.DBMap;
import com.mcnc.smart.hybrid.adapter.api.Adapter;
import com.mcnc.smart.hybrid.adapter.api.IAdapterJob;
import com.mcnc.smart.hybrid.common.code.Codes;
import com.mcnc.smart.hybrid.common.server.JsonAdaptorObject;

@Adapter(trcode = { "NCCW902" })
public class NCCW902_Adapter extends AbstractTemplateAdapter implements
		IAdapterJob {

	private static final ILogger logger = LoggerService
			.getLogger(NCCW902_Adapter.class);
	@Autowired
	private DBAdapter dbAdapter;

	public JsonAdaptorObject onProcess(JsonAdaptorObject obj) {
		
		JsonNode reqRootNode = obj.get(JsonAdaptorObject.TYPE.REQUEST);
		JsonNode reqHeaderNode = reqRootNode.findValue(Codes._JSON_MESSAGE_HEADER);
		
		NCCW902Request request				= new NCCW902Request ( obj );
//		CowayCommonHeader reqHeader			= request.getHeader();
		NCCW902Request_Body reqBody			= request.getBody();		
		
		logger.info( ">>>> NCCW902 REQUEST ::" );
		logger.info( obj.toString() );
		
		NCCW902Response_Body resBody	= new NCCW902Response_Body();
		JsonAdaptorObject resObj 		= new JsonAdaptorObject();
		
		SqlSession session	= dbAdapter.openSession( "BIZMOBNFC", false );
		
		try {
			DBMap queryParameters	= new DBMap();
			
			queryParameters.put( "I_ORDER_NO", reqBody.getI_ORDER_NO() );
			queryParameters.put( "I_CREATED_DATE", reqBody.getI_CREATED_DATE() );
			queryParameters.put( "I_GOODS_SN", reqBody.getI_GOODS_SN() );
			queryParameters.put( "I_CYCLE_MODE", reqBody.getI_CYCLE_MODE() );
			queryParameters.put( "I_RSVN_HOUR", reqBody.getI_RSVN_HOUR() );
			queryParameters.put( "I_RSVN_MINUTE", reqBody.getI_RSVN_MINUTE() );
			queryParameters.put( "I_CYCLE_DATE", reqBody.getI_CYCLE_DATE() );
			queryParameters.put( "I_POST_TYPE", reqBody.getI_POST_TYPE() );
			
			int result = dbAdapter.selectOne( "BIZMOBNFC", "NCCW902.selectRsvnData", queryParameters, Integer.class );
			
			if( result < 1 ) {//데이터가 없는경우
				dbAdapter.insert( session, "NCCW902.insertRsvnData", queryParameters );
			} else {
				dbAdapter.update( session, "NCCW902.updateRsvnData", queryParameters );				
			}
			
			dbAdapter.commitAndClose( session );
			
			NfcCommonResponse response = new NfcCommonResponse( reqHeaderNode );
			
			logger.info( ">>>> NCCW902 RESPONSE ::" );
			logger.info( response.getNfcCommonResponse().toString() );
			
			return makeResponse( resObj, response.getNfcCommonResponse() );
			
		} catch (Exception e) {
			dbAdapter.rollbackAndClose( session );
			logger.error( ">>>> NCCW902 Exception ::", e );
			//살균순환정보 저장 중 에러가 발생하였습니다.
			NfcCommonResponse errResponse = new NfcCommonResponse();			
			
			try {
				errResponse.setNfcErrorMessage( "살균순환정보 저장중 오류가 발생하였습니다." );
				errResponse.setNfcCommonHeader( reqHeaderNode );
			} catch (AdapterException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}			
			return makeResponse( resObj, errResponse.getNfcCommonResponse() );
		}

	}

}
