package adapter.nfc;

import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.node.JsonNodeFactory;
import org.codehaus.jackson.node.ObjectNode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.ObjectUtils;

import adapter.common.NfcCommonResponse;
import adapter.model.header.CowayCommonHeader;
import adapter.model.NCCR902.NCCR902Request;
import adapter.model.NCCR902.NCCR902Request_Body; 
import adapter.model.NCCR902.NCCR902Response; 
import adapter.model.NCCR902.NCCR902Response_Body; 

import com.mcnc.bizmob.adapter.AbstractTemplateAdapter;
import com.mcnc.bizmob.adapter.DBAdapter;
import com.mcnc.bizmob.adapter.exception.AdapterException;
import com.mcnc.bizmob.adapter.util.AdapterUtil;
import com.mcnc.smart.common.logging.ILogger;
import com.mcnc.smart.common.logging.LoggerService;
import com.mcnc.smart.db.type.DBMap;
import com.mcnc.smart.hybrid.adapter.api.Adapter;
import com.mcnc.smart.hybrid.adapter.api.IAdapterJob;
import com.mcnc.smart.hybrid.common.code.Codes;
import com.mcnc.smart.hybrid.common.server.JsonAdaptorObject;

@Adapter(trcode = { "NCCR902" })
public class NCCR902_Adapter extends AbstractTemplateAdapter implements
		IAdapterJob {

	private static final ILogger logger = LoggerService
			.getLogger(NCCR902_Adapter.class);
	@Autowired
	private DBAdapter dbAdapter;

	public JsonAdaptorObject onProcess(JsonAdaptorObject obj) {
		
		JsonNode reqRootNode = obj.get(JsonAdaptorObject.TYPE.REQUEST);
		JsonNode reqHeaderNode = reqRootNode.findValue(Codes._JSON_MESSAGE_HEADER);	
		
		NCCR902Request request		= new NCCR902Request ( obj );
//		CowayCommonHeader reqHeader	= request.getHeader();
		NCCR902Request_Body reqBody	= request.getBody();
		
		logger.info( ">>>> NCCR902 REQUEST ::" );
		logger.info( obj.toString() );
		
		NCCR902Response_Body resBody	= new NCCR902Response_Body();
		JsonAdaptorObject resObj 		= new JsonAdaptorObject();
		
		String orderNo	= reqBody.getI_ORDER_NO();
		String goodsNo	= reqBody.getI_GOODS_SN();
		
		DBMap queryParameters	= new DBMap(); 
		queryParameters.put( "I_ORDER_NO", orderNo );
		queryParameters.put( "I_GOODS_SN", goodsNo );
		
		try {
			resBody	= dbAdapter.selectOne( "BIZMOBNFC", "NCCR902.selectRsvnInfo", queryParameters, NCCR902Response_Body.class );
			
			logger.info( ">>>> NCCR902 SELECT RESULT ::" + AdapterUtil.ConvertJsonNode( resBody ) );
			
			ObjectNode resultNode	= JsonNodeFactory.instance.objectNode();
			if ( resBody == null ) {
				resultNode.put( "O_ORDER_NO", "" );
				resultNode.put( "O_CREATED_DATE", "" );
				resultNode.put( "O_GOODS_SN", "" );
				resultNode.put( "O_CYCLE_MODE", "" );
				resultNode.put( "O_RSVN_HOUR", "" );
				resultNode.put( "O_RSVN_MINUTE", "" );
				resultNode.put( "O_CYCLE_DATE", "" );
				resultNode.put( "O_POST_TYPE", "" );
			} else {
				resultNode.put( "O_ORDER_NO", resBody.getO_ORDER_NO() );
				resultNode.put( "O_CREATED_DATE", resBody.getO_CREATED_DATE() );
				resultNode.put( "O_GOODS_SN", resBody.getO_GOODS_SN() );
				resultNode.put( "O_CYCLE_MODE", resBody.getO_CYCLE_MODE() );
				resultNode.put( "O_RSVN_HOUR", resBody.getO_RSVN_HOUR() );
				resultNode.put( "O_RSVN_MINUTE", resBody.getO_RSVN_MINUTE() );
				resultNode.put( "O_CYCLE_DATE", resBody.getO_CYCLE_DATE() );
				resultNode.put( "O_POST_TYPE", resBody.getO_POST_TYPE() );				
			}
			NfcCommonResponse response = new NfcCommonResponse( reqHeaderNode, resultNode );
			
			logger.info( ">>>> NCCR902 RESPONSE ::" );
			logger.info( response.getNfcCommonResponse().toString() );
			
			return makeResponse( resObj, response.getNfcCommonResponse() );
			
		} catch ( Exception e ) {
			logger.error( ">>>> NCCR902 Exception ::", e );
			NfcCommonResponse errResponse = new NfcCommonResponse(); 
			
			try {
				errResponse.setNfcErrorMessage( "살균순환정보 조회중 오류가 발생하였습니다." );
				errResponse.setNfcCommonHeader( reqHeaderNode );
			} catch (AdapterException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			return makeResponse( resObj, errResponse.getNfcCommonResponse() );
		}
	}

}
