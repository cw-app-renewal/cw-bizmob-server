package adapter.nfc;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.codehaus.jackson.JsonNode;
import org.springframework.beans.factory.annotation.Autowired;

import adapter.common.NfcCommonResponse;
import adapter.model.NCCW901.NCCW901Request;
import adapter.model.NCCW901.NCCW901Request_Body;
import adapter.model.NCCW901.NCCW901Request_Body_I_ITAB;
import adapter.model.NCCW901.NCCW901Response_Body;

import com.mcnc.bizmob.adapter.AbstractTemplateAdapter;
import com.mcnc.bizmob.adapter.DBAdapter;
import com.mcnc.bizmob.adapter.exception.AdapterException;
import com.mcnc.bizmob.adapter.util.AdapterUtil;
import com.mcnc.smart.common.logging.ILogger;
import com.mcnc.smart.common.logging.LoggerService;
import com.mcnc.smart.db.type.DBMap;
import com.mcnc.smart.hybrid.adapter.api.Adapter;
import com.mcnc.smart.hybrid.adapter.api.IAdapterJob;
import com.mcnc.smart.hybrid.common.code.Codes;
import com.mcnc.smart.hybrid.common.server.JsonAdaptorObject;

@Adapter(trcode = { "NCCW901" })
public class NCCW901_Adapter extends AbstractTemplateAdapter implements
		IAdapterJob {

	private static final ILogger logger = LoggerService
			.getLogger(NCCW901_Adapter.class);
	@Autowired
	private DBAdapter dbAdapter;

	public JsonAdaptorObject onProcess(JsonAdaptorObject obj) {
		
		JsonNode reqRootNode = obj.get(JsonAdaptorObject.TYPE.REQUEST);
		JsonNode reqHeaderNode = reqRootNode.findValue(Codes._JSON_MESSAGE_HEADER);
		
		NCCW901Request request				= new NCCW901Request ( obj );
//		CowayCommonHeader reqHeader			= request.getHeader();		
		
		NCCW901Request_Body reqBody			= request.getBody();
		List< NCCW901Request_Body_I_ITAB > reqList	= reqBody.getI_ITAB();
		
		logger.info( ">>>> NCCW901 REQUEST ::" );
		logger.info( obj.toString() );
		
		NCCW901Response_Body resBody	= new NCCW901Response_Body(); 		
		JsonAdaptorObject resObj 		= new JsonAdaptorObject();
		
		SqlSession session	= dbAdapter.openSession( "BIZMOBNFC", false );
		try {
			DBMap queryParameters = new DBMap();
			for ( NCCW901Request_Body_I_ITAB item : reqList ) {
				queryParameters.put( "I_GOODS_SN", item.getI_GOODS_SN() );
				queryParameters.put("I_RAW_DATE", item.getI_RAW_DATE() );
				queryParameters.put("I_COLD", item.getI_COLD() );
				queryParameters.put("I_COLD_INT", item.getI_COLD_INT() );
				queryParameters.put("I_HOT", item.getI_HOT() );
				queryParameters.put("I_HOT_INT", item.getI_HOT_INT() );
				queryParameters.put("I_NORMAL", item.getI_NORMAL() );
				queryParameters.put("I_NORMAL_INT", item.getI_NORMAL_INT() );
				queryParameters.put("I_EQUNR", item.getI_EQUNR() );
				queryParameters.put("I_ORDER_NO", item.getI_ORDER_NO());
				
				int result	= dbAdapter.selectOne( "BIZMOBNFC", "NCCW901.selectDrinkData", queryParameters, Integer.class );
				if ( result < 1 ) {//없는경우
					dbAdapter.insert( session, "NCCW901.insertDrinkData", queryParameters );
				} else {
					dbAdapter.update( session, "NCCW901.updateDrinkData", queryParameters );
				}
				queryParameters.clear();
			}
			dbAdapter.commitAndClose( session );
			
			NfcCommonResponse response = new NfcCommonResponse( reqHeaderNode );
			
			logger.info( ">>>> NCCW901 RESPONSE ::" );
			logger.info( response.getNfcCommonResponse().toString() );
			
			return makeResponse( resObj, response.getNfcCommonResponse() );
			
		} catch ( Exception e ) {
			dbAdapter.rollbackAndClose( session );			
			logger.error( ">>>> NCCW901 Exception ::", e );
			//음용량 저장중 에러가 발생하였습니다.
			NfcCommonResponse errResponse = new NfcCommonResponse();
			
			try {
				errResponse.setNfcErrorMessage( "음용량 저장중 오류가 발생하였습니다." );
				errResponse.setNfcCommonHeader( reqHeaderNode );
			} catch (AdapterException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			return makeResponse( resObj, errResponse.getNfcCommonResponse() );
			
		}		
	}

}
